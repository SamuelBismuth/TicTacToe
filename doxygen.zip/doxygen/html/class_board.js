var class_board =
[
    [ "Board", "class_board.html#a80ecb92c1fca312fda215651d29112d3", null ],
    [ "Board", "class_board.html#a463280204ec3e3de05419a0ab0cf70fc", null ],
    [ "~Board", "class_board.html#af73f45730119a1fd8f6670f53f959e68", null ],
    [ "getDimension", "class_board.html#a20069538cfbd36c7349815926712275d", null ],
    [ "operator=", "class_board.html#ab99394dbe04a19be6e2f78c55745fbf3", null ],
    [ "operator=", "class_board.html#a336eab0a339c1eb5e1afff292e01e772", null ],
    [ "operator[]", "class_board.html#a6d1f25c8673abf3c242deff399d1c811", null ],
    [ "operator<<", "class_board.html#ad799faa7c15b047d09f3fa52406c95d5", null ]
];