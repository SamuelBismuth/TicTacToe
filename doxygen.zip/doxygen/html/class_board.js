var class_board =
[
    [ "Board", "class_board.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "Board", "class_board.html#a80ecb92c1fca312fda215651d29112d3", null ],
    [ "Board", "class_board.html#afff05d626d310b2c6b5a8d93531f51f4", null ],
    [ "~Board", "class_board.html#af73f45730119a1fd8f6670f53f959e68", null ],
    [ "draw", "class_board.html#ad65d532e29d2ca704ac2a2dd81159830", null ],
    [ "getDimension", "class_board.html#a43d73cb1ca646a1b0127a3b360f1285d", null ],
    [ "operator=", "class_board.html#ad3d2dd9f214eae89d55055612e5f14a5", null ],
    [ "operator=", "class_board.html#a336eab0a339c1eb5e1afff292e01e772", null ],
    [ "operator[]", "class_board.html#a8312b348cb2d006c245cc6b47a036fae", null ],
    [ "setBoard", "class_board.html#a01d13db8b52af5de7e4ca1ef1d5877c2", null ],
    [ "setDimension", "class_board.html#acffa72c5f16aaf310017e0b9ddc91a7c", null ],
    [ "setMatrix", "class_board.html#ace29578627b507adbce65e8a0297b58f", null ],
    [ "size", "class_board.html#afc6c8cfe684a99ad8cc4a7ada62a3485", null ],
    [ "operator<<", "class_board.html#aeb1b6f0bb2bfaac0e30fe8234d86bc10", null ],
    [ "operator>>", "class_board.html#acde31729f3680542e5a7a516dee99db3", null ]
];