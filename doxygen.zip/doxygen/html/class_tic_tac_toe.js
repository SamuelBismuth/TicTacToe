var class_tic_tac_toe =
[
    [ "TicTacToe", "class_tic_tac_toe.html#a6038e282a4d0d26161db1b8bcef2966d", null ],
    [ "board", "class_tic_tac_toe.html#a7f8fb69bea96af41dd705efc4c5ad089", null ],
    [ "play", "class_tic_tac_toe.html#a4da0081ad10e8906504e1654361e03aa", null ],
    [ "winner", "class_tic_tac_toe.html#afeae762ed2299fef0b4404e5e20bc8cf", null ]
];