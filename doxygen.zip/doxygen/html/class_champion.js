var class_champion =
[
    [ "name", "class_champion.html#ab048aa8f8e19c362f4e89fe5e4a71911", null ],
    [ "play", "class_champion.html#ae8be4edbee93e074d2195ce364764c54", null ]
];