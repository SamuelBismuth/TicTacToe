var struct_r_g_b =
[
    [ "RGB", "struct_r_g_b.html#ac82f37558b845c294de41eb2558c6619", null ],
    [ "RGB", "struct_r_g_b.html#ac893e0c7963ecaf217cd58ce0a1269ad", null ],
    [ "blue", "struct_r_g_b.html#aa40a251e4fd9dfe9fb1c9b55585405cf", null ],
    [ "green", "struct_r_g_b.html#a165f9a144b000655025edaacae2cae6b", null ],
    [ "red", "struct_r_g_b.html#afbb25f9ed818b8149ffd04c5640d8c7a", null ]
];