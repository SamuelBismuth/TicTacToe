var files =
[
    [ "Board.h", "_board_8h_source.html", null ],
    [ "Champion.h", "_champion_8h_source.html", null ],
    [ "DummyPlayers.h", "_dummy_players_8h_source.html", null ],
    [ "IllegalCharException.h", "_illegal_char_exception_8h_source.html", null ],
    [ "IllegalCoordinateException.h", "_illegal_coordinate_exception_8h_source.html", null ],
    [ "Piece.h", "_piece_8h_source.html", null ],
    [ "Player.h", "_player_8h_source.html", null ],
    [ "TicTacToe.h", "_tic_tac_toe_8h_source.html", null ]
];