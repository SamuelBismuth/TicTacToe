var class_illegal_player =
[
    [ "name", "class_illegal_player.html#a1f4d55d85709391dcd9036ab9dd021a3", null ],
    [ "play", "class_illegal_player.html#a26f903ab24fe9e6dac9e40c1df0c58e6", null ]
];