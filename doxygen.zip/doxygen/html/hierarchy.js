var hierarchy =
[
    [ "Board", "class_board.html", null ],
    [ "exception", null, [
      [ "IllegalCharException", "class_illegal_char_exception.html", null ],
      [ "IllegalCoordinateException", "class_illegal_coordinate_exception.html", null ]
    ] ],
    [ "Piece", "class_piece.html", null ]
];