var hierarchy =
[
    [ "Board", "class_board.html", null ],
    [ "Count", "struct_count.html", null ],
    [ "exception", null, [
      [ "IllegalCharException", "class_illegal_char_exception.html", null ],
      [ "IllegalCoordinateException", "class_illegal_coordinate_exception.html", null ]
    ] ],
    [ "Piece", "class_piece.html", null ],
    [ "Player", "class_player.html", [
      [ "Champion", "class_champion.html", null ],
      [ "ExceptionPlayer", "class_exception_player.html", null ],
      [ "IllegalPlayer", "class_illegal_player.html", null ],
      [ "XYPlayer", "class_x_y_player.html", null ],
      [ "YXPlayer", "class_y_x_player.html", null ]
    ] ],
    [ "RGB", "struct_r_g_b.html", null ],
    [ "TicTacToe", "class_tic_tac_toe.html", null ]
];