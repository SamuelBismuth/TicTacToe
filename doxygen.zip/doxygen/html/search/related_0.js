var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_board.html#aeb1b6f0bb2bfaac0e30fe8234d86bc10',1,'Board::operator&lt;&lt;()'],['../class_piece.html#a9ac1aa5b62366842ef65d45289107048',1,'Piece::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../class_board.html#acde31729f3680542e5a7a516dee99db3',1,'Board']]]
];
