var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_piece.html#a9ac1aa5b62366842ef65d45289107048',1,'Piece::operator&lt;&lt;()'],['../class_board.html#aeb1b6f0bb2bfaac0e30fe8234d86bc10',1,'Board::operator&lt;&lt;()']]]
];
