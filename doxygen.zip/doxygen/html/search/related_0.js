var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_piece.html#a66d9ec951efc6dfe5511f328b27a4b53',1,'Piece::operator&lt;&lt;()'],['../class_board.html#ad799faa7c15b047d09f3fa52406c95d5',1,'Board::operator&lt;&lt;()']]]
];
