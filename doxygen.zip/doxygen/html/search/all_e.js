var searchData=
[
  ['_7eboard',['~Board',['../class_board.html#af73f45730119a1fd8f6670f53f959e68',1,'Board']]]
];
