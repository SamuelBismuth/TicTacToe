var searchData=
[
  ['piece',['Piece',['../class_piece.html',1,'Piece'],['../class_piece.html#ac57de5803bbad829b143bc7268267dc1',1,'Piece::Piece()'],['../class_piece.html#ad9f976e136af13d97b041bf62d9d9867',1,'Piece::Piece(char pawn)']]]
];
