var searchData=
[
  ['get_5fpiece',['get_piece',['../class_piece.html#af5e0b1b9ea85bcb3e61bb180005aa28a',1,'Piece']]],
  ['getchar',['getChar',['../class_player.html#a60f6323bebebcc6393ebed4c0e91682c',1,'Player']]],
  ['getdimension',['getDimension',['../class_board.html#a43d73cb1ca646a1b0127a3b360f1285d',1,'Board']]]
];
