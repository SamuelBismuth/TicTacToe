var searchData=
[
  ['winner',['winner',['../class_tic_tac_toe.html#afeae762ed2299fef0b4404e5e20bc8cf',1,'TicTacToe']]]
];
