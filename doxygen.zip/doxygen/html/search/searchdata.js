var indexSectionsWithContent =
{
  0: "bcdegioprstwxy~",
  1: "bceiprtxy",
  2: "bdgiopstw~",
  3: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Friends"
};

