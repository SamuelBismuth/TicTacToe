var searchData=
[
  ['get_5fpiece',['get_piece',['../class_piece.html#af5e0b1b9ea85bcb3e61bb180005aa28a',1,'Piece']]],
  ['getdimension',['getDimension',['../class_board.html#a20069538cfbd36c7349815926712275d',1,'Board']]]
];
