var searchData=
[
  ['board',['Board',['../class_board.html',1,'Board'],['../class_board.html#a80ecb92c1fca312fda215651d29112d3',1,'Board::Board(const Board &amp;board)'],['../class_board.html#a463280204ec3e3de05419a0ab0cf70fc',1,'Board::Board(size_t dimension)']]]
];
