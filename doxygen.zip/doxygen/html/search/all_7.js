var searchData=
[
  ['set_5fpiece',['set_piece',['../class_piece.html#a788f3823fc4ad6b710c5fb0b325efbb8',1,'Piece']]],
  ['setboard',['setBoard',['../class_board.html#a01d13db8b52af5de7e4ca1ef1d5877c2',1,'Board']]],
  ['setchar',['setChar',['../class_player.html#a3bb1ba756251ad489c11760ae1d181f3',1,'Player']]],
  ['setdimension',['setDimension',['../class_board.html#acffa72c5f16aaf310017e0b9ddc91a7c',1,'Board']]],
  ['setmatrix',['setMatrix',['../class_board.html#ace29578627b507adbce65e8a0297b58f',1,'Board']]],
  ['size',['size',['../class_board.html#afc6c8cfe684a99ad8cc4a7ada62a3485',1,'Board']]]
];
