var searchData=
[
  ['illegalcharexception',['IllegalCharException',['../class_illegal_char_exception.html',1,'IllegalCharException'],['../class_illegal_char_exception.html#af9ea15541e4a914251dcb57bfc9e94f8',1,'IllegalCharException::IllegalCharException()']]],
  ['illegalcoordinateexception',['IllegalCoordinateException',['../class_illegal_coordinate_exception.html',1,'IllegalCoordinateException'],['../class_illegal_coordinate_exception.html#a52b77be69e44f08120a6770f48257cde',1,'IllegalCoordinateException::IllegalCoordinateException()']]]
];
