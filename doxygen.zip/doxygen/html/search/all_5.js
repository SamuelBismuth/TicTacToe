var searchData=
[
  ['set_5fpiece',['set_piece',['../class_piece.html#a788f3823fc4ad6b710c5fb0b325efbb8',1,'Piece']]]
];
