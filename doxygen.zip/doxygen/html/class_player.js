var class_player =
[
    [ "getChar", "class_player.html#a60f6323bebebcc6393ebed4c0e91682c", null ],
    [ "name", "class_player.html#a4ea7393ae408338c47914623657a0840", null ],
    [ "play", "class_player.html#ae90dfe84cca63c54c5c787b8adaca089", null ],
    [ "setChar", "class_player.html#a3bb1ba756251ad489c11760ae1d181f3", null ],
    [ "myChar", "class_player.html#a8dbe4bc13f82153c49d3e9b35382cde8", null ]
];