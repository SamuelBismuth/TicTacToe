var class_x_y_player =
[
    [ "name", "class_x_y_player.html#a0932d930ceab1e981913bee98d0b858c", null ],
    [ "play", "class_x_y_player.html#aeeebbfa1c2a441feccd90fe152ae1994", null ]
];