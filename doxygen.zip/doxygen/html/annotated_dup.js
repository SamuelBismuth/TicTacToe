var annotated_dup =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "Champion", "class_champion.html", "class_champion" ],
    [ "Count", "struct_count.html", "struct_count" ],
    [ "ExceptionPlayer", "class_exception_player.html", "class_exception_player" ],
    [ "IllegalCharException", "class_illegal_char_exception.html", "class_illegal_char_exception" ],
    [ "IllegalCoordinateException", "class_illegal_coordinate_exception.html", "class_illegal_coordinate_exception" ],
    [ "IllegalPlayer", "class_illegal_player.html", "class_illegal_player" ],
    [ "Piece", "class_piece.html", "class_piece" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "RGB", "struct_r_g_b.html", "struct_r_g_b" ],
    [ "TicTacToe", "class_tic_tac_toe.html", "class_tic_tac_toe" ],
    [ "XYPlayer", "class_x_y_player.html", "class_x_y_player" ],
    [ "YXPlayer", "class_y_x_player.html", "class_y_x_player" ]
];