var annotated_dup =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "IllegalCharException", "class_illegal_char_exception.html", "class_illegal_char_exception" ],
    [ "IllegalCoordinateException", "class_illegal_coordinate_exception.html", "class_illegal_coordinate_exception" ],
    [ "Piece", "class_piece.html", "class_piece" ]
];