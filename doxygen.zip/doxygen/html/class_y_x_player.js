var class_y_x_player =
[
    [ "name", "class_y_x_player.html#ac60eef874d745ee62d417b4aff92350c", null ],
    [ "play", "class_y_x_player.html#af75f52669b17242d145560c5b5b9e5bc", null ]
];