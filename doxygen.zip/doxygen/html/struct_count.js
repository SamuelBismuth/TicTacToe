var struct_count =
[
    [ "flag", "struct_count.html#aa5ac6587b96556fa3bd9a287a2e8bd22", null ],
    [ "sum", "struct_count.html#a3834461d0417723bc3a4b7168cd25705", null ]
];