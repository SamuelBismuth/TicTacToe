var class_illegal_coordinate_exception =
[
    [ "IllegalCoordinateException", "class_illegal_coordinate_exception.html#a52b77be69e44f08120a6770f48257cde", null ],
    [ "theCoordinate", "class_illegal_coordinate_exception.html#a4cccbd561d0f1c8c04af3993d90fe956", null ]
];