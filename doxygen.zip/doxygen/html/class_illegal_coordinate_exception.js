var class_illegal_coordinate_exception =
[
    [ "IllegalCoordinateException", "class_illegal_coordinate_exception.html#a52b77be69e44f08120a6770f48257cde", null ],
    [ "theCoordinate", "class_illegal_coordinate_exception.html#a8250ed5989b96c2b12575a333be59870", null ]
];