var class_piece =
[
    [ "Piece", "class_piece.html#ac57de5803bbad829b143bc7268267dc1", null ],
    [ "Piece", "class_piece.html#ad9f976e136af13d97b041bf62d9d9867", null ],
    [ "get_piece", "class_piece.html#af5e0b1b9ea85bcb3e61bb180005aa28a", null ],
    [ "operator char", "class_piece.html#a6c3089e6e020e7ce2bb6f8f79a3f0e70", null ],
    [ "operator=", "class_piece.html#a54ec6e235407f3a548d4359d8e77729e", null ],
    [ "set_piece", "class_piece.html#a788f3823fc4ad6b710c5fb0b325efbb8", null ],
    [ "operator<<", "class_piece.html#a66d9ec951efc6dfe5511f328b27a4b53", null ]
];