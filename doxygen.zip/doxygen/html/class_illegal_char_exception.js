var class_illegal_char_exception =
[
    [ "IllegalCharException", "class_illegal_char_exception.html#af9ea15541e4a914251dcb57bfc9e94f8", null ],
    [ "theChar", "class_illegal_char_exception.html#aad044b8ef051ad43d6b0b3c54d54d069", null ]
];